! function() {
    function E(E) {
        var e = Array.prototype.slice.call(E),
            t = [],
            n = [];
        for (const E of e) n.push(_(E)), t.push(S(E));
        return {
            complexities: t,
            stringifiedArguments: n
        }
    }

    function _(E) {
        return o(t(T(E)))
    }

    function e(E) {
        return `${g}${E}${g}`
    }

    function t(E) {
        return E.replace(p, "")
    }

    function n(E) {
        try {
            return null === E ? I : void 0 === E ? P : N(E) ? A : Object.prototype.toString.call(E)
        } catch {
            return l
        }
    }

    function N(E) {
        return !!(E && "object" == typeof E && "nodeType" in E && 1 === E.nodeType && E.outerHTML)
    }

    function S(E) {
        switch (n(E)) {
            case I:
            case P:
            case L:
            case C:
            case a:
            case f:
                return M;
            case l:
            case s:
            case H:
            case u:
                return F;
            case A:
                return U;
            case d:
            case D:
            case i:
                for (var _ of E) {
                    var e = n(_);
                    if (e === s || e === l || e === D) return F
                }
                return M;
            default:
                return F
        }
    }

    function o(E) {
        return E.length > c ? E.slice(0, c) + "\u2026" : E
    }

    function r(E) {
        let _ = typeof E;
        return "function" === _ || "symbol" === _ ? e(E.toString()) : "undefined" === _ ? e("undefined") : "bigint" === _ && e(`${E.toString()}n`)
    }

    function R(E) {
        let _ = r(E);
        return _ || E
    }

    function O(E, _) {
        if ("" === E) return _;
        if (n(_) === D) return _.map(R);
        return "function" == typeof Object.getOwnPropertyDescriptor(this, E).get ? e("\u2026") : R(_)
    }

    function T(E) {
        try {
            var _ = n(E);
            switch (_) {
                case I:
                    return e("null");
                case P:
                    return e("undefined");
                case L:
                    return e("" + E);
                case C:
                    return e(`${E.toString()}n`);
                case a:
                    return e(E ? "true" : "false");
                case A:
                    return e(E.outerHTML);
                case H:
                case s:
                    return e(E.toString());
                case f:
                    return '"' + E.replace(/"/g, "'") + '"';
                case i:
                    return `// ${_} (${(E=Array.prototype.slice.call(E,0)).length})\n[${E.map((E=>E.tagName?e(`<${E.tagName.toLowerCase()}/>`):e(`${E.nodeName.toLowerCase()}`)))}]`;
                case D:
                    return `// ${_} (${E.length})\n[${E.map(T)}]`;
                case d:
                    return `// ${_} (${(E=[...E]).length})\n{${E.map(T)}}`;
                case l:
                    return `// ${_} \n${JSON.stringify(E,O,2)}`;
                default:
                    return r(E) ? r(E) : `// ${_} \n${JSON.stringify(E,O,2)}`
            }
        } catch {
            return "/* Log Skipped: Sorry, this log cannot be shown. You might need to use the browser console instead. */"
        }
    }
    const c = 2e3,
        I = "TYPE_NULL",
        P = "TYPE_UNDEFINED",
        A = "TYPE_ELEMENT_NODE",
        D = "[object Array]",
        i = "[object NodeList]",
        a = "[object Boolean]",
        s = "[object Function]",
        u = "[object global]",
        L = "[object Number]",
        C = "[object BigInt]",
        l = "[object Object]",
        f = "[object String]",
        H = "[object Symbol]",
        d = "[object Set]";
    window.__cpConsoleSafeStringify = E;
    const g = "\ue799\ue798",
        p = new RegExp(`"${g}|${g}"|${g}`, "gm"),
        M = 1,
        F = 2,
        U = 3
}(), window.HUB_EVENTS = {
        ASSET_ADDED: "ASSET_ADDED",
        ASSET_DELETED: "ASSET_DELETED",
        ASSET_DESELECTED: "ASSET_DESELECTED",
        ASSET_SELECTED: "ASSET_SELECTED",
        ASSET_UPDATED: "ASSET_UPDATED",
        CONSOLE_CHANGE: "CONSOLE_CHANGE",
        CONSOLE_CLOSED: "CONSOLE_CLOSED",
        CONSOLE_EVENT: "CONSOLE_EVENT",
        CONSOLE_OPENED: "CONSOLE_OPENED",
        CONSOLE_RUN_COMMAND: "CONSOLE_RUN_COMMAND",
        CONSOLE_SERVER_CHANGE: "CONSOLE_SERVER_CHANGE",
        EMBED_ACTIVE_PEN_CHANGE: "EMBED_ACTIVE_PEN_CHANGE",
        EMBED_ACTIVE_THEME_CHANGE: "EMBED_ACTIVE_THEME_CHANGE",
        EMBED_ATTRIBUTE_CHANGE: "EMBED_ATTRIBUTE_CHANGE",
        EMBED_RESHOWN: "EMBED_RESHOWN",
        FORMAT_FINISH: "FORMAT_FINISH",
        FORMAT_ERROR: "FORMAT_ERROR",
        FORMAT_START: "FORMAT_START",
        IFRAME_PREVIEW_RELOAD_CSS: "IFRAME_PREVIEW_RELOAD_CSS",
        IFRAME_PREVIEW_URL_CHANGE: "IFRAME_PREVIEW_URL_CHANGE",
        KEY_PRESS: "KEY_PRESS",
        LINTER_FINISH: "LINTER_FINISH",
        LINTER_START: "LINTER_START",
        PEN_CHANGE_SERVER: "PEN_CHANGE_SERVER",
        PEN_CHANGE: "PEN_CHANGE",
        PEN_EDITOR_CLOSE: "PEN_EDITOR_CLOSE",
        PEN_EDITOR_CODE_FOLD: "PEN_EDITOR_CODE_FOLD",
        PEN_EDITOR_ERRORS: "PEN_EDITOR_ERRORS",
        PEN_EDITOR_EXPAND: "PEN_EDITOR_EXPAND",
        PEN_EDITOR_FOLD_ALL: "PEN_EDITOR_FOLD_ALL",
        PEN_EDITOR_LOADED: "PEN_EDITOR_LOADED",
        PEN_EDITOR_REFRESH_REQUEST: "PEN_EDITOR_REFRESH_REQUEST",
        PEN_EDITOR_RESET_SIZES: "PEN_EDITOR_RESET_SIZES",
        PEN_EDITOR_SIZES_CHANGE: "PEN_EDITOR_SIZES_CHANGE",
        PEN_EDITOR_UI_CHANGE_SERVER: "PEN_EDITOR_UI_CHANGE_SERVER",
        PEN_EDITOR_UI_CHANGE: "PEN_EDITOR_UI_CHANGE",
        PEN_EDITOR_UI_DISABLE: "PEN_EDITOR_UI_DISABLE",
        PEN_EDITOR_UI_ENABLE: "PEN_EDITOR_UI_ENABLE",
        PEN_EDITOR_UNFOLD_ALL: "PEN_EDITOR_UNFOLD_ALL",
        PEN_ERROR_INFINITE_LOOP: "PEN_ERROR_INFINITE_LOOP",
        PEN_ERROR_RUNTIME: "PEN_ERROR_RUNTIME",
        PEN_ERRORS: "PEN_ERRORS",
        PEN_LIVE_CHANGE: "PEN_LIVE_CHANGE",
        PEN_LOGS: "PEN_LOGS",
        PEN_MANIFEST_CHANGE: "PEN_MANIFEST_CHANGE",
        PEN_MANIFEST_FULL: "PEN_MANIFEST_FULL",
        PEN_PREVIEW_FINISH: "PEN_PREVIEW_FINISH",
        PEN_PREVIEW_START: "PEN_PREVIEW_START",
        PEN_SAVED: "PEN_SAVED",
        POPUP_CLOSE: "POPUP_CLOSE",
        POPUP_OPEN: "POPUP_OPEN",
        POST_CHANGE: "POST_CHANGE",
        POST_SAVED: "POST_SAVED",
        PROCESSING_FINISH: "PROCESSING_FINISH",
        PROCESSING_START: "PROCESSED_STARTED"
    },
    function() {
        function E() {
            if (window.console)
                for (const E of t) window.console[E] && (window.console[E] = function() {
                    this.apply(console, arguments), _(E, arguments)
                }.bind(console[E]))
        }

        function _(E, _) {
            const e = window.__cpConsoleSafeStringify(_),
                {
                    complexities: t,
                    stringifiedArguments: n
                } = e,
                N = {
                    topic: HUB_EVENTS.CONSOLE_EVENT,
                    data: {
                        function: E,
                        arguments: n,
                        complexity: Math.max.apply(null, t)
                    }
                };
            window.parent.postMessage(N, "*")
        }

        function e(E) {
            const {
                topic: _,
                data: e
            } = "object" == typeof E.data ? E.data : {};
            if (_ === HUB_EVENTS.CONSOLE_RUN_COMMAND) try {
                const E = window.eval(e.command);
                console.log(E)
            } catch (E) {
                return void console.error(E.message)
            }
        }
        const t = ["clear", "count", "debug", "error", "info", "log", "table", "time", "timeEnd", "warn"];
        E(), window.addEventListener("message", e, !1)
    }();